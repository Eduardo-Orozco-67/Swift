import SwiftUI

struct ContentView: View {
    @State var animar = false
    var body: some View {
        ZStack{
            Color(.cyan)
                .opacity(0.3)
                .background(
                    LinearGradient(gradient: Gradient(colors: [.white,.cyan,.cyan]), startPoint: .top, endPoint: .bottom)
                )
            VStack(alignment: .center) {
                Text("Bob Esponja")
                    .font(.largeTitle)
                    .foregroundColor(.black)
                    .bold()
                    .animation(.spring(dampingFraction: 0.5), value: animar)
                    .shadow(color: .yellow, radius: .pi, x: 2, y: 5)
                
                Image("bob")
                    .resizable()
                    .frame(width: 350, height: 350)
                    .imageScale(.small)
                    .clipShape(Circle())
                    .shadow(color: .black, radius: .pi, x: 10, y: 10)
                    .rotationEffect(
                        Angle(degrees: animar ? 360:0)
                    )
                    .animation(.spring(dampingFraction: 0.5), value: animar)
                    .padding(.bottom,40)
                
                VStack(alignment: .center, spacing: 30){
                    
                    Text("HOLAAA")
                        .font(.largeTitle)
                        .foregroundColor(.black)
                        .bold()
                        .shadow(color: .yellow, radius: .pi, x: 2, y: 5)
                    
                    Text("Calamardo")
                        .font(.largeTitle)
                        .foregroundColor(.black)
                        .bold()
                        .shadow(color: .yellow, radius: .pi, x: 2, y: 5)
                        .opacity(0.5)
                    
                    Button(action: {
                        animar.toggle()
                            }, label: {
                                Text("Girame".uppercased())
                                    .font(.largeTitle)
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color.accentColor)
                                    .cornerRadius(10)
                                    .shadow(radius: 10)
                                })
                }
            }
        }
        .ignoresSafeArea()
        
    }
}
