//
//  TarjetaView.swift
//  app_eduardo
//
//  Created by ADMIN UNACH on 23/03/23.
//

import SwiftUI

struct TarjetaView: View {
    @State var animar = false
    var body: some View {
        ZStack{
            Color(.cyan)
                .opacity(0.3)
                .background(
                    LinearGradient(gradient: Gradient(colors: [.white,.mint,.blue]), startPoint: .top, endPoint: .bottom)
                )
            HStack{
                ZStack {
                    Image("fondo")
                        .resizable()
                        .frame(width: 350, height: 350)
                        .imageScale(.small)
                        .clipShape(Rectangle())
                        .shadow(color: .black, radius: .pi, x: 10, y: 10)
                        .rotationEffect(
                            Angle(degrees: animar ? 360:0)
                        )
                        .animation(.spring(dampingFraction: 0.5), value: animar)
                        .padding(.bottom,40)
                    VStack(alignment: .center, spacing: 1){
                        Image("bob")
                            .resizable()
                            .frame(width: 150, height: 150)
                            .imageScale(.small)
                            .clipShape(Circle())
                            .shadow(color: .black, radius: .pi, x: 10, y: 10)
                            .rotationEffect(
                                Angle(degrees: animar ? 360:0)
                            )
                            .animation(.spring(dampingFraction: 0.5), value: animar)
                            .padding(.bottom,10)
                        VStack(alignment: .center, spacing: 1)
                        {
                            Text("Bob Esponja ")
                                .font(.system(size: 35))
                                .font(.largeTitle)
                                .foregroundColor(.black)
                                .bold()
                                .shadow(color: .yellow, radius: .pi, x: 2, y: 5)
                            
                            Text("Cocinero del KK")
                                .font(.system(size: 20))
                                .font(.largeTitle)
                                .foregroundColor(.black)
                                .bold()
                                .shadow(color: .yellow, radius: .pi, x: 2, y: 5)
                        }.padding(10)
                            HStack(alignment: .center, spacing: 30){
                                VStack(alignment: .center, spacing: 10){
                                    Image(systemName: "star.fill")
                                        .resizable()
                                        .frame(width: 30, height: 30)
                                        .imageScale(.small)
                                    Text("Star")
                                        .font(.system(size: 20))
                                        .font(.largeTitle)
                                        .foregroundColor(.black)
                                        .bold()
                                        .shadow(color: .yellow, radius: .pi, x: 2, y: 5)
                                        .padding(.bottom)
                                }
                                VStack(alignment: .center, spacing: 10){
                                    Image(systemName: "heart.fill")
                                        .resizable()
                                        .frame(width: 30, height: 30)
                                        .imageScale(.small)
                                    Text("Heart")
                                        .font(.system(size: 20))
                                        .font(.largeTitle)
                                        .foregroundColor(.black)
                                        .bold()
                                        .shadow(color: .yellow, radius: .pi, x: 2, y: 5)
                                        .padding(.bottom)
                                }
                                
                                VStack(alignment: .center, spacing: 10){
                                    Image(systemName: "message.fill")
                                        .resizable()
                                        .frame(width: 30, height: 30)
                                        .imageScale(.small)
                                    Text("Message")
                                        .font(.system(size: 20))
                                        .font(.largeTitle)
                                        .foregroundColor(.black)
                                        .bold()
                                        .shadow(color: .yellow, radius: .pi, x: 2, y: 5)
                                        .padding(.bottom)
                                }
         
                            }
                    }
                }
            }

        }
        .ignoresSafeArea()
    }
}

struct TarjetaView_Previews: PreviewProvider {
    static var previews: some View {
        TarjetaView()
    }
}
