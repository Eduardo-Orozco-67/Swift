//
//  RefereeView.swift
//  App2_Eduardo
//
//  Created by ADMIN UNACH on 23/03/23.
//

import SwiftUI

struct RefereeView: View {
    
    @Binding var equipoA: Int
    @Binding var equipoB: Int
    
    var body: some View {
        
        HStack(alignment: .center, spacing: 70){
            Button(action: {equipoA+=1
                    }, label: {
                        Text("Team A Score".uppercased())
                            .font(.system(size: 15))
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(10)
                            .shadow(radius: 10)
                        })
            Button(action: {equipoB += 1
                    }, label: {
                        Text("Team B Score".uppercased())
                            .font(.system(size: 15))
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.red)
                            .cornerRadius(10)
                            .shadow(radius: 10)
                        })
        }
        VStack{
            Button(action: {equipoB = 0; equipoA = 0
            }, label: {
                        Text("Reset".uppercased())
                            .font(.system(size: 15))
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.gray)
                            .cornerRadius(10)
                            .shadow(radius: 10)
                        })
        }
    }
}

struct RefereeView_Previews: PreviewProvider {
    static var previews: some View {
        RefereeView(equipoA:.constant(0), equipoB:.constant(0))
    }
}
