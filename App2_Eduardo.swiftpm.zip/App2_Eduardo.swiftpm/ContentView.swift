import SwiftUI

struct ContentView: View {
    
    @State var teamA = 0
    @State var teamB = 0
    
    @State var tiempo = 0.0
    @State var isEditing = false
    
    var body: some View {
        
        VStack(alignment: .center, spacing: 30){
            Text("Scoreboard")
                .font(.largeTitle)
            
            VStack{
                
                ScoreView(tA: $teamA, tB: $teamB)
                RefereeView(equipoA: $teamA, equipoB: $teamB)
                SliderView(time: $tiempo)

            }
        }
    }
    
}
