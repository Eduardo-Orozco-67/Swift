//
//  SliderView.swift
//  App2_Eduardo
//
//  Created by ADMIN UNACH on 24/03/23.
//

import SwiftUI

struct SliderView: View {
    
    @Binding var time: Double
    
    var body: some View {
        VStack{
            Slider(value: $time, in: 0...100,
                   step: 1,
                   minimumValueLabel: Text("min"),
                   maximumValueLabel: Text("max")){
            }
            Text("\(time)")
        }
    }
}

struct SliderView_Previews: PreviewProvider {
    static var previews: some View {
        SliderView(time:.constant(0))
    }
}
