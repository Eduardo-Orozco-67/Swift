//
//  ScoreView.swift
//  App2_Eduardo
//
//  Created by ADMIN UNACH on 24/03/23.
//

import SwiftUI

struct ScoreView: View {
    
    @Binding var tA: Int
    @Binding var tB: Int
    
    var body: some View {
        HStack(alignment: .center, spacing: 200){
            
            VStack{
                Text("Team A")
                    .font(.system(size: 20))
                    .fontWeight(.semibold)
                Text("\(tA)")
                    .font(.system(size: 20))
                    .fontWeight(.bold)
                    .foregroundColor(.blue)
            }
            
            VStack{
                Text("Team B")
                    .font(.system(size: 20))
                    .fontWeight(.semibold)
                Text("\(tB)")
                    .font(.system(size: 20))
                    .fontWeight(.bold)
                    .foregroundColor(.red)
            }
        }
    }
}

struct ScoreView_Previews: PreviewProvider {
    static var previews: some View {
        ScoreView(tA:.constant(0), tB:.constant(0))
    }
}
